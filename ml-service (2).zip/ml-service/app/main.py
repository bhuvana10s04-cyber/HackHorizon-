"""FastAPI layer. Run:  uvicorn app.main:app --port 8001"""
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

from . import config
from .scoring import ModelNotReady, RiskEngine

state = {"engine": None, "error": None}


@asynccontextmanager
async def lifespan(app):
    try:
        state["engine"] = RiskEngine.load()
    except ModelNotReady as e:
        state["error"] = str(e)
    yield


app = FastAPI(title="ScamShield ML Service", version="1.0.0", lifespan=lifespan,
              description="Mule-account risk engine. SYNTHETIC DEMO DATA ONLY.")


class AssessRequest(BaseModel):
    identifier: str = Field(..., min_length=1, max_length=300, examples=["rahul12@okaxis"])


def _engine():
    if state["engine"] is None:
        raise HTTPException(503, state["error"] or "Model not loaded. Run: python -m app.train")
    return state["engine"]


@app.get("/health")
def health():
    return {"status": "ok" if state["engine"] else "model_not_loaded", "detail": state["error"],
            "data_source": config.DATA_SOURCE}


@app.post("/assess")
def assess(req: AssessRequest):
    try:
        return _engine().assess(req.identifier)
    except ValueError as e:
        raise HTTPException(422, str(e))


@app.get("/model-info")
def model_info():
    e = _engine()
    return {"version": e.version, "data_source": config.DATA_SOURCE, "disclaimer": config.DISCLAIMER,
            "min_transactions_required": config.MIN_TXNS_30D, "metrics": e.metrics()}


@app.get("/demo-identifiers")
def demo_identifiers():
    return {"data_source": config.DATA_SOURCE, "identifiers": _engine().demo_identifiers()}
