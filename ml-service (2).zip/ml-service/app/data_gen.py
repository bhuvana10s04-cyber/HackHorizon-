"""Synthetic dataset + money-flow graph generator. ALL DATA IS FAKE."""
import numpy as np
import pandas as pd

from .config import N_ENTITIES, SEED

NAMES = ["rahul", "priya", "amit", "sneha", "vikram", "anita", "suresh", "kavya", "ravi", "meena",
         "arjun", "divya", "kiran", "pooja", "manoj", "lakshmi", "sanjay", "nisha"]
SHOPS = ["sharma.store", "tea.corner", "mobile.hub", "fresh.mart", "medico", "book.nook", "kirana", "snack.bar"]
BANKS = ["okaxis", "oksbi", "okhdfcbank", "ybl", "paytm", "ibl"]

# (mean, sigma) for lognormal, (a, b) for beta, scalar for poisson/exponential means
PARAMS = {
    "personal": dict(age=(6.6, 0.7), txn=25, su=0.4, ru=0.5, amt=(6.4, 0.8), rnd=(2, 6), night=(1.5, 10),
                     pt=(2, 5), hold=72, rep=0.05, new=(2, 6)),
    "merchant": dict(age=(6.8, 0.6), txn=200, su=0.6, ru=0.05, amt=(5.9, 0.7), rnd=(3, 5), night=(2, 8),
                     pt=(2, 8), hold=96, rep=0.1, new=(4, 4)),
    "mule": dict(age=(4.0, 0.6), txn=80, su=0.8, ru=0.04, amt=(8.3, 0.5), rnd=(5, 3), night=(3, 5),
                 pt=(8, 1.5), hold=3, rep=1.2, new=(6, 2)),
    # stealthy mules look much closer to normal accounts
    "stealth_mule": dict(age=(5.6, 0.6), txn=35, su=0.55, ru=0.15, amt=(7.0, 0.6), rnd=(3, 4), night=(2, 6),
                         pt=(4, 3), hold=20, rep=0.4, new=(4, 3)),
}


def _identifier(rng, i, kind):
    if kind == "personal" and rng.random() < 0.35:
        n = (i * 7919 + 1234567) % 10**9  # bijective -> unique
        return f"{6 + i % 4}{n:09d}"
    base = rng.choice(SHOPS) if kind == "merchant" else rng.choice(NAMES)
    return f"{base}{i}@{rng.choice(BANKS)}"


def _row(rng, i, kind):
    p = PARAMS[kind]
    txn = int(rng.poisson(p["txn"]))
    if rng.random() < 0.06:  # sparse accounts -> will be "Insufficient Data"
        txn = int(rng.integers(0, 5))
    senders = min(txn, max(1, int(txn * p["su"] * rng.uniform(0.7, 1.1)))) if txn else 0
    receivers = min(txn, max(1, int(txn * p["ru"] * rng.uniform(0.7, 1.3)) or 1)) if txn else 0
    return {
        "identifier": _identifier(rng, i, kind),
        "kind": kind,
        "account_age_days": float(max(1, rng.lognormal(*p["age"]))),
        "txn_count_30d": txn,
        "unique_senders_30d": senders,
        "unique_receivers_30d": receivers,
        "avg_txn_amount": float(rng.lognormal(*p["amt"])),
        "pct_round_amounts": float(rng.beta(*p["rnd"])),
        "night_txn_ratio": float(rng.beta(*p["night"])),
        "pass_through_ratio": float(rng.beta(*p["pt"])),
        "avg_hold_time_hours": float(rng.exponential(p["hold"])),
        "fraud_reports_count": int(rng.poisson(p["rep"])),
        "new_sender_ratio": float(rng.beta(*p["new"])),
    }


def generate_entities(n=N_ENTITIES, seed=SEED, label_noise=0.03):
    rng = np.random.default_rng(seed)
    kinds = rng.choice(["personal", "merchant", "mule", "stealth_mule"], size=n, p=[0.74, 0.14, 0.08, 0.04])
    df = pd.DataFrame([_row(rng, i, k) for i, k in enumerate(kinds)])
    label = df["kind"].isin(["mule", "stealth_mule"]).astype(int).values
    flip = rng.random(n) < label_noise  # imperfect ground truth, like the real world
    df["is_mule"] = np.where(flip, 1 - label, label)
    return df


def generate_edges(df, seed=SEED):
    """Directed money-flow edges. Legit flows form a DAG (no cycles) except a few
    family-style reciprocal pairs; mules form circular rings plus fan-in from victims."""
    rng = np.random.default_rng(seed + 1)
    ids = df["identifier"].tolist()
    kinds = df["kind"].tolist()
    personal = [i for i, k in enumerate(kinds) if k == "personal"]
    merchants = [i for i, k in enumerate(kinds) if k == "merchant"]
    mules = [i for i, k in enumerate(kinds) if k in ("mule", "stealth_mule")]
    edges = []

    def amt(mu=6.0):
        return round(float(rng.lognormal(mu, 0.8)), 2)

    for pos, i in enumerate(personal):
        later = personal[pos + 1:]
        for _ in range(int(rng.integers(1, 4))):
            if (rng.random() < 0.5 and merchants) or not later:
                if not merchants:
                    continue
                j = int(rng.choice(merchants))
            else:
                j = int(rng.choice(later))
            edges.append((ids[i], ids[j], amt()))
    for _ in range(max(1, len(personal) // 40)):  # reciprocal family pairs
        a, b = rng.choice(personal, size=2, replace=False)
        edges.append((ids[a], ids[b], amt()))
        edges.append((ids[b], ids[a], amt()))

    order = list(rng.permutation(mules))
    n_ring = int(len(order) * 0.8)  # the rest are isolated mules the graph can't expose
    ringed, k = order[:n_ring], 0
    while k < len(ringed):
        size = int(rng.integers(3, 7))
        ring = ringed[k:k + size]
        k += size
        if len(ring) < 3:
            break
        for a, b in zip(ring, ring[1:] + ring[:1]):
            edges.append((ids[a], ids[b], amt(8.0)))
    for m in mules:
        for v in rng.choice(personal, size=int(rng.integers(3, 9)), replace=False):
            edges.append((ids[int(v)], ids[m], amt(7.5)))

    return pd.DataFrame(edges, columns=["src", "dst", "amount"])
