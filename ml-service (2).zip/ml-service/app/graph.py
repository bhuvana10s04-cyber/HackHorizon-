"""NetworkX graph analysis: circular money-movement rings and linked accounts."""
import networkx as nx
import pandas as pd


def build_graph(edges_df):
    g = nx.DiGraph()
    for r in edges_df.itertuples(index=False):
        if g.has_edge(r.src, r.dst):
            g[r.src][r.dst]["amount"] += r.amount
        else:
            g.add_edge(r.src, r.dst, amount=r.amount)
    return g


def _scc_sizes(g):
    size = {}
    for comp in nx.strongly_connected_components(g):
        for n in comp:
            size[n] = len(comp)
    return size


def graph_features(g, entities):
    """Per-identifier graph features. neighbor_reported_count uses fraud *reports*
    (a signal), never the training label (which would leak the answer)."""
    scc = _scc_sizes(g)
    reported = set(entities.loc[entities["fraud_reports_count"] > 0, "identifier"])
    rows = []
    for ident in entities["identifier"]:
        if ident in g:
            nbrs = set(g.predecessors(ident)) | set(g.successors(ident))
            rows.append((ident, scc.get(ident, 1), g.in_degree(ident), g.out_degree(ident),
                         len(nbrs & reported)))
        else:
            rows.append((ident, 1, 0, 0, 0))
    return pd.DataFrame(rows, columns=["identifier", "ring_size", "in_degree", "out_degree",
                                       "neighbor_reported_count"])


def ring_members(g, ident, limit=8):
    if ident not in g:
        return []
    for comp in nx.strongly_connected_components(g):
        if ident in comp:
            return sorted(n for n in comp if n != ident)[:limit] if len(comp) > 1 else []
    return []


def linked_accounts(g, ident, limit=5):
    if ident not in g:
        return []
    return sorted(set(g.predecessors(ident)) | set(g.successors(ident)))[:limit]
