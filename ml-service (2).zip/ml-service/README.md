# ScamShield ML Service (synthetic demo data)

Mule-account risk engine: synthetic data -> feature engineering -> Random Forest -> graph (NetworkX) -> explainable score.

## Run
```bash
cd backend/ml-service
python -m venv .venv && .venv\Scripts\activate      # Windows  (Linux/Mac: source .venv/bin/activate)
pip install -r requirements.txt
python -m app.train                 # creates artifacts/ (model, data, metrics)
uvicorn app.main:app --port 8001    # docs: http://127.0.0.1:8001/docs
```
Tests: `python -m unittest discover -s tests -p "test_engine.py"` (slow, ~1-2 min) and `pytest tests/test_api.py`.

## Endpoints
| Method | Path | Purpose |
|---|---|---|
| GET | /health | liveness + model loaded? |
| POST | /assess | `{"identifier": "name@bank" or "9876543210"}` -> assessment |
| GET | /model-info | version, metrics, disclaimer |
| GET | /demo-identifiers | sample identifiers for demos |

`/assess` returns `status` (`ASSESSED` | `INSUFFICIENT_DATA`), `risk_score` (0-100 or null), `risk_level`
(LOW / MODERATE / HIGH / VERY_HIGH / INSUFFICIENT_DATA), `recommendation` (PROCEED_WITH_CAUTION / VERIFY / PAUSE),
`reasons[]`, `graph{ring_size, ring_members, linked_accounts}`, `data_source`, `disclaimer`. Invalid input -> HTTP 422.

## Honest limitations
- All data is synthetic; metrics say nothing about real-world accuracy. Never present them as such.
- Identifiers outside the demo dataset, or with < 5 transactions in 30 days, return **Insufficient Data** (never "safe").
- Reasons are one-feature-at-a-time counterfactuals (score drop if the feature were typical of a legit account): an approximation, not causal proof.
- No real bank / NPCI / UPI integration exists.
