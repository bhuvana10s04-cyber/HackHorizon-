"""Identifier validation and the feature list shared by training and scoring."""
import re

UPI_RE = re.compile(r"^[a-z0-9][a-z0-9.\-_]{1,255}@[a-z]{2,64}$")
PHONE_RE = re.compile(r"^[6-9]\d{9}$")

BASE_FEATURES = [
    "account_age_days",
    "txn_count_30d",
    "unique_senders_30d",
    "unique_receivers_30d",
    "avg_txn_amount",
    "pct_round_amounts",
    "night_txn_ratio",
    "pass_through_ratio",
    "avg_hold_time_hours",
    "fraud_reports_count",
    "new_sender_ratio",
]
ENGINEERED = ["sender_receiver_ratio"]
GRAPH_FEATURES = ["ring_size", "in_degree", "out_degree", "neighbor_reported_count"]
FEATURES = BASE_FEATURES + ENGINEERED + GRAPH_FEATURES

LABELS = {
    "account_age_days": "Account age (days)",
    "txn_count_30d": "Transactions in last 30 days",
    "unique_senders_30d": "Distinct senders in 30 days",
    "unique_receivers_30d": "Distinct receivers in 30 days",
    "avg_txn_amount": "Average transaction amount (INR)",
    "pct_round_amounts": "Share of round-number amounts",
    "night_txn_ratio": "Share of night-time transactions",
    "pass_through_ratio": "Share of received money forwarded within 24h",
    "avg_hold_time_hours": "Average hours money stays in account",
    "fraud_reports_count": "Fraud reports against this account",
    "new_sender_ratio": "Share of first-time senders",
    "sender_receiver_ratio": "Senders-to-receivers ratio",
    "ring_size": "Size of circular money-movement group",
    "in_degree": "Accounts that send money to it",
    "out_degree": "Accounts it sends money to",
    "neighbor_reported_count": "Linked accounts that have fraud reports",
}


def normalize_identifier(raw):
    """Return (normalized_identifier, type) or raise ValueError."""
    if raw is None or not str(raw).strip():
        raise ValueError("Identifier is empty.")
    s = str(raw).strip().lower()
    if "@" in s:
        if UPI_RE.match(s):
            return s, "UPI_ID"
        raise ValueError("UPI ID must look like name@bank (letters, digits, '.', '-', '_').")
    digits = s.replace(" ", "").replace("-", "").lstrip("+")
    if len(digits) == 12 and digits.startswith("91"):
        digits = digits[2:]
    if PHONE_RE.match(digits):
        return digits, "PHONE"
    raise ValueError("Phone number must be 10 digits starting with 6-9 (optionally prefixed by +91).")


def add_engineered(df):
    df = df.copy()
    df["sender_receiver_ratio"] = df["unique_senders_30d"] / df["unique_receivers_30d"].clip(lower=1)
    return df
