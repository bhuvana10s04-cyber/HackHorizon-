"""Risk scoring: model probability -> 0-100 score, level, recommendation, explanations."""
import json

import joblib
import pandas as pd

from . import config
from .features import FEATURES, LABELS, normalize_identifier
from .graph import build_graph, linked_accounts, ring_members

LEVELS = [(75, "VERY_HIGH"), (50, "HIGH"), (25, "MODERATE"), (0, "LOW")]
RECOMMENDATION = {
    "LOW": ("PROCEED_WITH_CAUTION",
            "Few risk signals in demo data. This is not a guarantee of safety - still confirm the recipient."),
    "MODERATE": ("VERIFY", "Some risk signals. Confirm the recipient through another channel before paying."),
    "HIGH": ("PAUSE", "Several strong risk signals. Pause and verify independently before sending money."),
    "VERY_HIGH": ("PAUSE", "Very strong risk signals. Do not pay. Consider reporting this identifier."),
}


def level_for(score):
    for floor, name in LEVELS:
        if score >= floor:
            return name


class ModelNotReady(RuntimeError):
    pass


class RiskEngine:
    def __init__(self, bundle, entities, edges):
        self.model = bundle["model"]
        self.features = bundle["features"]
        self.median = bundle["legit_median"]
        self.version = bundle["version"]
        self.entities = entities.set_index("identifier")
        self.graph = build_graph(edges)

    @classmethod
    def load(cls):
        for p in (config.MODEL_PATH, config.ENTITIES_PATH, config.EDGES_PATH):
            if not p.exists():
                raise ModelNotReady(f"{p.name} not found. Run: python -m app.train")
        return cls(joblib.load(config.MODEL_PATH), pd.read_csv(config.ENTITIES_PATH),
                   pd.read_csv(config.EDGES_PATH))

    def _p(self, row_df):
        return float(self.model.predict_proba(row_df[self.features])[:, 1][0])

    def _reasons(self, row, base_p, top=5, min_drop_points=3.0):
        """Counterfactual: how many points does the score fall if this feature were typical
        of a legitimate account? (one feature at a time - an approximation, not causal proof)."""
        out = []
        for f in self.features:
            alt = row.copy()
            alt[f] = self.median[f]
            drop = (base_p - self._p(alt)) * 100
            if drop >= min_drop_points:
                val = float(row[f].iloc[0])
                out.append({"feature": f, "description": LABELS[f], "value": round(val, 2),
                            "typical_legit_value": round(float(self.median[f]), 2),
                            "score_impact": round(drop, 1)})
        return sorted(out, key=lambda r: -r["score_impact"])[:top]

    def _base(self, ident, id_type):
        return {"identifier": ident, "identifier_type": id_type, "data_source": config.DATA_SOURCE,
                "disclaimer": config.DISCLAIMER, "model_version": self.version}

    def assess(self, raw_identifier):
        ident, id_type = normalize_identifier(raw_identifier)  # may raise ValueError
        res = self._base(ident, id_type)
        if ident not in self.entities.index:
            return {**res, "status": "INSUFFICIENT_DATA", "risk_score": None, "risk_level": "INSUFFICIENT_DATA",
                    "recommendation": "VERIFY", "message": "Insufficient Data",
                    "advice": "This identifier is not in the demo dataset. That does NOT mean it is safe - "
                              "verify the recipient before paying.",
                    "reasons": [], "graph": None}
        row = self.entities.loc[[ident]].reset_index()
        n_txn = int(row["txn_count_30d"].iloc[0])
        if n_txn < config.MIN_TXNS_30D:
            return {**res, "status": "INSUFFICIENT_DATA", "risk_score": None, "risk_level": "INSUFFICIENT_DATA",
                    "recommendation": "VERIFY", "message": "Insufficient Data",
                    "advice": f"Only {n_txn} transactions in the last 30 days - too little to assess. "
                              "This does NOT mean it is safe.",
                    "reasons": [], "graph": None}
        p = self._p(row)
        score = int(round(p * 100))
        level = level_for(score)
        rec, advice = RECOMMENDATION[level]
        return {**res, "status": "ASSESSED", "risk_score": score, "risk_level": level,
                "recommendation": rec, "message": level.replace("_", " ") + " RISK", "advice": advice,
                "reasons": self._reasons(row, p),
                "graph": {"ring_size": int(row["ring_size"].iloc[0]),
                          "ring_members": ring_members(self.graph, ident),
                          "linked_accounts": linked_accounts(self.graph, ident)}}

    def demo_identifiers(self):
        df = self.entities.reset_index()
        pick = lambda mask: df.loc[mask, "identifier"].head(2).tolist()
        scoreable = df["txn_count_30d"] >= config.MIN_TXNS_30D
        return {
            "likely_high_risk": pick(scoreable & (df["kind"] == "mule") & (df["ring_size"] > 1)),
            "stealthy_mule": pick(scoreable & (df["kind"] == "stealth_mule")),
            "legitimate_personal": pick(scoreable & (df["kind"] == "personal")),
            "busy_merchant": pick(scoreable & (df["kind"] == "merchant")),
            "insufficient_data_sparse": pick(~scoreable),
            "unknown_identifier": ["nobody.unknown@okaxis"],
        }

    def metrics(self):
        if config.METRICS_PATH.exists():
            return json.loads(config.METRICS_PATH.read_text())
        return {}
