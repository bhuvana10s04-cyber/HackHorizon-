"""Generate synthetic data, engineer features, train + evaluate a Random Forest, save artifacts.
Run:  python -m app.train
"""
import json

import joblib
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import precision_score, recall_score, roc_auc_score, confusion_matrix
from sklearn.model_selection import cross_val_score, train_test_split

from . import config
from .data_gen import generate_edges, generate_entities
from .features import FEATURES, add_engineered
from .graph import build_graph, graph_features


def build_dataset(seed=config.SEED, n=config.N_ENTITIES):
    entities = generate_entities(n=n, seed=seed)
    edges = generate_edges(entities, seed=seed)
    g = build_graph(edges)
    entities = entities.merge(graph_features(g, entities), on="identifier", how="left")
    entities = add_engineered(entities)
    return entities, edges


def train(seed=config.SEED, n=config.N_ENTITIES, save=True):
    entities, edges = build_dataset(seed, n)
    # Only learn from accounts we would actually score at inference time.
    data = entities[entities["txn_count_30d"] >= config.MIN_TXNS_30D]
    X, y = data[FEATURES], data["is_mule"]
    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.25, stratify=y, random_state=seed)

    def make():
        return RandomForestClassifier(n_estimators=300, max_depth=10, min_samples_leaf=5,
                                      class_weight="balanced_subsample", random_state=seed, n_jobs=-1)

    model = make().fit(X_tr, y_tr)
    proba = model.predict_proba(X_te)[:, 1]
    pred = (proba >= 0.5).astype(int)
    metrics = {
        "data_source": config.DATA_SOURCE,
        "n_entities": int(len(entities)),
        "n_training_rows": int(len(data)),
        "mule_rate": round(float(y.mean()), 4),
        "precision": round(float(precision_score(y_te, pred, zero_division=0)), 4),
        "recall": round(float(recall_score(y_te, pred)), 4),
        "roc_auc": round(float(roc_auc_score(y_te, proba)), 4),
        "cv_roc_auc_5fold": round(float(cross_val_score(make(), X, y, cv=5, scoring="roc_auc").mean()), 4),
        "confusion_matrix [[TN,FP],[FN,TP]]": confusion_matrix(y_te, pred).tolist(),
        "feature_importance": {f: round(float(v), 4) for f, v in
                               sorted(zip(FEATURES, model.feature_importances_), key=lambda t: -t[1])},
        "note": "Metrics are on synthetic data only and say nothing about real-world accuracy.",
    }
    final = make().fit(X, y)  # refit on all scoreable rows for the shipped model
    legit_median = data.loc[data["is_mule"] == 0, FEATURES].median().to_dict()
    bundle = {"model": final, "features": FEATURES, "legit_median": legit_median,
              "version": f"rf-synthetic-seed{seed}"}
    if save:
        config.ARTIFACTS.mkdir(exist_ok=True)
        joblib.dump(bundle, config.MODEL_PATH)
        entities.to_csv(config.ENTITIES_PATH, index=False)
        edges.to_csv(config.EDGES_PATH, index=False)
        config.METRICS_PATH.write_text(json.dumps(metrics, indent=2))
    return bundle, metrics


if __name__ == "__main__":
    _, m = train()
    print(json.dumps(m, indent=2))
    print(f"\nSaved model + data to {config.ARTIFACTS}")
