"""API tests (need: pip install -r requirements.txt, and `python -m app.train` run once)."""
import pytest
from fastapi.testclient import TestClient

from app.main import app


@pytest.fixture(scope="module")
def client():
    with TestClient(app) as c:  # runs lifespan -> loads model
        yield c


def test_health(client):
    r = client.get("/health")
    assert r.status_code == 200 and r.json()["status"] == "ok"


def test_assess_unknown_is_insufficient(client):
    r = client.post("/assess", json={"identifier": "nobody.unknown@okaxis"})
    assert r.status_code == 200
    body = r.json()
    assert body["status"] == "INSUFFICIENT_DATA" and body["risk_score"] is None
    assert body["data_source"] == "SYNTHETIC_DEMO_DATA"


def test_assess_invalid_identifier_422(client):
    assert client.post("/assess", json={"identifier": "not valid"}).status_code == 422


def test_assess_missing_field_422(client):
    assert client.post("/assess", json={}).status_code == 422


def test_demo_identifiers_then_assess(client):
    ids = client.get("/demo-identifiers").json()["identifiers"]
    r = client.post("/assess", json={"identifier": ids["likely_high_risk"][0]})
    assert r.status_code == 200
    body = r.json()
    assert body["status"] == "ASSESSED" and 0 <= body["risk_score"] <= 100
    assert body["recommendation"] in {"PROCEED_WITH_CAUTION", "VERIFY", "PAUSE"}


def test_model_info(client):
    r = client.get("/model-info")
    assert r.status_code == 200 and "metrics" in r.json()
