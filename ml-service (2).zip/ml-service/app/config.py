from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
ARTIFACTS = BASE_DIR / "artifacts"
MODEL_PATH = ARTIFACTS / "model.joblib"
ENTITIES_PATH = ARTIFACTS / "entities.csv"
EDGES_PATH = ARTIFACTS / "edges.csv"
METRICS_PATH = ARTIFACTS / "metrics.json"

SEED = 42
N_ENTITIES = 3000
MIN_TXNS_30D = 5  # below this we refuse to score: "Insufficient Data"

DATA_SOURCE = "SYNTHETIC_DEMO_DATA"
DISCLAIMER = (
    "This assessment uses SYNTHETIC DEMO DATA only. It is not connected to any bank, "
    "NPCI or real fraud database. A low score is NOT a guarantee of safety."
)
