"""Engine tests - run with:  python -m unittest discover -s tests   (or pytest)"""
import unittest

from app import config
from app.data_gen import generate_edges, generate_entities
from app.features import normalize_identifier
from app.graph import build_graph, graph_features
from app.scoring import RiskEngine, level_for
from app.train import train


class EngineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        bundle, cls.metrics = train(save=False)
        from app.train import build_dataset
        entities, edges = build_dataset()
        cls.entities = entities
        cls.engine = RiskEngine(bundle, entities, edges)

    # --- identifier validation
    def test_valid_upi(self):
        self.assertEqual(normalize_identifier(" Rahul.S@OKAXIS "), ("rahul.s@okaxis", "UPI_ID"))

    def test_valid_phone_with_country_code(self):
        self.assertEqual(normalize_identifier("+91 98765-43210"), ("9876543210", "PHONE"))

    def test_invalid_identifiers(self):
        for bad in ["", "   ", "abc", "12345", "5876543210", "a b@bank", "@bank", "x@1", "user@"]:
            with self.assertRaises(ValueError, msg=bad):
                normalize_identifier(bad)

    # --- level boundaries
    def test_level_boundaries(self):
        self.assertEqual([level_for(s) for s in (0, 24, 25, 49, 50, 74, 75, 100)],
                         ["LOW", "LOW", "MODERATE", "MODERATE", "HIGH", "HIGH", "VERY_HIGH", "VERY_HIGH"])

    # --- insufficient data
    def test_unknown_identifier_is_insufficient_not_safe(self):
        r = self.engine.assess("nobody.unknown@okaxis")
        self.assertEqual(r["status"], "INSUFFICIENT_DATA")
        self.assertIsNone(r["risk_score"])
        self.assertEqual(r["message"], "Insufficient Data")
        self.assertNotEqual(r["risk_level"], "LOW")

    def test_sparse_account_is_insufficient(self):
        sparse = self.entities[self.entities["txn_count_30d"] < config.MIN_TXNS_30D]
        self.assertGreater(len(sparse), 0)
        r = self.engine.assess(sparse["identifier"].iloc[0])
        self.assertEqual(r["status"], "INSUFFICIENT_DATA")

    # --- scoring
    def test_score_range_and_labelling(self):
        for ident in self.entities["identifier"].head(80):
            r = self.engine.assess(ident)
            self.assertEqual(r["data_source"], "SYNTHETIC_DEMO_DATA")
            self.assertIn("SYNTHETIC", r["disclaimer"])
            if r["status"] == "ASSESSED":
                self.assertTrue(0 <= r["risk_score"] <= 100)
                self.assertIn(r["risk_level"], {"LOW", "MODERATE", "HIGH", "VERY_HIGH"})

    def test_ringed_mules_score_higher_than_legit_on_average(self):
        e = self.entities
        ok = e["txn_count_30d"] >= config.MIN_TXNS_30D
        mules = e[ok & (e["kind"] == "mule") & (e["ring_size"] > 1)]["identifier"].head(40)
        legit = e[ok & (e["kind"] == "personal")]["identifier"].head(40)
        avg = lambda ids: sum(self.engine.assess(i)["risk_score"] for i in ids) / len(ids)
        self.assertGreater(avg(mules), avg(legit) + 30)

    def test_low_level_never_claims_safe(self):
        e = self.entities
        legit = e[(e["kind"] == "personal") & (e["txn_count_30d"] >= config.MIN_TXNS_30D)]["identifier"]
        for ident in legit:
            r = self.engine.assess(ident)
            if r["risk_level"] == "LOW":
                self.assertEqual(r["recommendation"], "PROCEED_WITH_CAUTION")
                self.assertIn("not a guarantee", r["advice"].lower())
                return
        self.fail("no LOW example found")

    def test_high_risk_has_reasons_and_pause(self):
        e = self.entities
        ids = e[(e["kind"] == "mule") & (e["ring_size"] > 1) & (e["txn_count_30d"] >= 5)]["identifier"]
        r = max((self.engine.assess(i) for i in ids), key=lambda x: x["risk_score"])
        self.assertEqual(r["recommendation"], "PAUSE")
        self.assertGreater(len(r["reasons"]), 0)
        self.assertTrue(all(x["score_impact"] > 0 for x in r["reasons"]))

    # --- graph
    def test_mule_rings_detected_and_legit_graph_mostly_acyclic(self):
        e = self.entities
        mules_in_ring = (e[e["kind"].isin(["mule", "stealth_mule"])]["ring_size"] > 1).mean()
        legit_in_ring = (e[e["kind"] == "personal"]["ring_size"] > 1).mean()
        self.assertGreater(mules_in_ring, 0.6)
        self.assertLess(legit_in_ring, 0.1)

    def test_graph_ring_members_returned(self):
        e = self.entities
        ident = e[(e["kind"] == "mule") & (e["ring_size"] > 1)]["identifier"].iloc[0]
        g = self.engine.graph
        from app.graph import ring_members
        self.assertGreaterEqual(len(ring_members(g, ident)), 2)

    # --- data + model sanity
    def test_dataset_is_deterministic(self):
        a, b = generate_entities(500, seed=7), generate_entities(500, seed=7)
        self.assertTrue(a.equals(b))

    def test_identifiers_unique(self):
        self.assertTrue(self.entities["identifier"].is_unique)

    def test_metrics_reasonable_but_not_perfect(self):
        self.assertGreater(self.metrics["roc_auc"], 0.7)
        self.assertLess(self.metrics["roc_auc"], 0.995)
        self.assertEqual(self.metrics["data_source"], "SYNTHETIC_DEMO_DATA")

    def test_demo_identifiers_resolve(self):
        d = self.engine.demo_identifiers()
        self.assertTrue(d["likely_high_risk"] and d["legitimate_personal"] and d["insufficient_data_sparse"])


if __name__ == "__main__":
    unittest.main()
